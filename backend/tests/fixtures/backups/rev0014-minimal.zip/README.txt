UniHelperProMax backup
======================

This zip holds one account's data from UniHelperProMax:

  files/      your notes (.md), recordings, documents, annotations and chats, in the same
              folders the app uses (<year>/<semester>/<course>/<class date>/...)
  data/       your classes, events, tasks, settings and themes, one JSON object per line
  manifest.json   when and with which version this backup was made, and a checksum of
                  every file, so the app can tell a damaged backup

API keys are never included: after a restore, enter them again in Settings.

To restore: open UniHelperProMax, go to Settings -> Backup & restore -> Restore from backup,
and choose this file. Restoring replaces all of the account's current data; a safety backup
of the current data is made first.

Don't change files inside this zip: the app refuses a backup whose contents changed.
